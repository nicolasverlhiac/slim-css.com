Slim - Framework CSS
====================

Framework accélérateur de projet web.

Si vous developper vous même vos sites internet, l'utilisation de ce framework est trés simple. Une structure déjà prete avec un CSS neutre et un habillage de type Flat Design.